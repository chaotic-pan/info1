/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */
import java.util.HashSet;

public class Game 
{
    private Parser parser;
    private Room currentRoom;
    private Room lastRoom;
    private World newGame;

    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        newGame = new World();
        newGame.createWorld();
        parser = new Parser();
        currentRoom=newGame.getStart();
        lastRoom = null;        
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.

        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            String output = processCommand(command);
            finished = (null == output);
            if (!finished)
            {
                System.out.println(output);
            }
        }
        System.out.println("Thank you for playing.  Good bye."); 
    }

    /**
     * This is a further method added by BK to
     * provide a clearer interface that can be tested:
     * Game processes a commandLine and returns output.
     * @param commandLine - the line entered as String
     * @return output of the command
     */
    public String processCommand(String commandLine){
        Command command = parser.getCommand(commandLine);
        return processCommand(command);
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to Where Is My Mum?!");
        System.out.println("Where Is My Mom?! is a new, incredibly boring adventure game.");
        System.out.println("Type 'help' if you need help.");
        System.out.println();
        System.out.println("You are " + currentRoom.getDescription());
        System.out.println(currentRoom.getExitString());
        System.out.println(currentRoom.getItemString());
        
        System.out.println();
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private String processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            return "I don't know what you mean...";       
        }
        String result = null;
        String commandWord = command.getCommandWord();
        if (commandWord.equals("help")) {
            result = printHelp();
        }
        else if (commandWord.equals("go")) {
            result = goRoom(command);
        }
        else if (commandWord.equals("quit")) {
            result = quit(command);
        }
        else if (commandWord.equals("look")) {
            result = look(command);
        }
        else if (commandWord.equals("eat")) {
            result = eat(command);
        }
        else if (commandWord.equals("talk")) {
            result = talk(command);
        }
        else if (commandWord.equals("back")) {
            result = back(command);
        }
        else if (commandWord.equals("take")) {
            result = take(command,currentRoom.getItem());
        }

        
        
        return result ;
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private String printHelp() 
    {
        return "You are lost. You are alone. You wander"
        +"\n"
        + "around the supermarket."
        +"\n"
        +"\n"
        +"...searching for your mum"
        +"\n"
        +"Your command words are:"
        +"\n"
        + parser.printCommands()
        +"\n";
    }

    /** 
     * Try to go in one direction. If there is an exit, enter
     * the new room, otherwise print an error message.
     */
    private String goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            return "Go where?";
        }

        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = null;
        nextRoom = currentRoom.getExit(direction);
        String result = "";
        if (nextRoom == null) {
            result += "There is no way!";
        }
        else {
            lastRoom = currentRoom;
            currentRoom = nextRoom;
            result += "You are " + currentRoom.getDescription()+"\n";
            result += currentRoom.getExitString() + "\n";
            result += currentRoom.getItemString();
            
        }
        return result + "\n";
    }

    private String back(Command command) 
    {
        String result = "";
        if (lastRoom == null) {
            result += "You haven't gone anywhere yet!";
        }
        else if (lastRoom == currentRoom) {
            result += "You already went back!";
        }
        else {
            currentRoom = lastRoom;
            result += "You are " + currentRoom.getDescription()+"\n";
            result += currentRoom.getExitString() + "\n";
            result += currentRoom.getItemString();
        }
        return result + "\n";
    }

    private String look(Command command)
    {
        return currentRoom.getExitString() + "\n" + currentRoom.getItemString();
    }
    
    private String eat(Command command){
        return "You have eaten now and are not hungry any more";
    }
    
    private String talk(Command command) {
        return "There is noone to talk to";
    }
    
    private String take(Command command, Item item) {
        if(!command.hasSecondWord()) {
            return "Take what?";
        }

        String takeItem = command.getSecondWord();
        String result =null;
        HashSet<Item> A = new HashSet<>();
        A=currentRoom.getItemNameHashSet();
        for (Item it : A){
            String presentItem=it.getItemName();
            if (presentItem.equals(takeItem)){
             result="You took the "+ takeItem;
             currentRoom.takeItem(it);
            }
        }
        if (result==null) {
            result= "There is no "+ takeItem +" here!";
        }
        return result;
    }
    
    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private String quit(Command command) 
    {
        if(command.hasSecondWord()) {
            return "Quit what?";
        }
        else {
            return null;  // signal that we want to quit
        }
    }
}
