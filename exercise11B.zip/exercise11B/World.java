
/**
 * Beschreiben Sie hier die Klasse world.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class World
{
    private Room startRoom;
    /**
     * Konstruktor f�r Objekte der Klasse world
     */
    public World()
    {
        createWorld();
    }
    
    public Room getStart()
    {
        return startRoom;
    }

    public void createWorld(){
      Room vegetables, fruits, cannedfood, bakery, cerealTeaCoffee, meat,
             dairyEggs, beverages, snacks, checkout, staffArea, rooftop,
             parkingLot;
        
        // create the rooms
        vegetables = new Room("in the vegetable section");
        fruits = new Room("in the fruit section");
        cannedfood = new Room("in the canned food isle");
        bakery = new Room("in the bakery isle");
        cerealTeaCoffee = new Room("in the cereal, coffee and tea isle");
        meat = new Room("in the meat section");
        dairyEggs = new Room("in the dairy products and eggs section");
        beverages = new Room("in the beverage section");
        snacks = new Room("in the snacks isle");
        checkout = new Room("at the checkout");
        staffArea = new Room("in the staff room");
        rooftop = new Room("on the roof");
        parkingLot = new Room("in front of the Supermarket");  
        
        // initialise room exits
        vegetables.setExit("south", parkingLot);
        vegetables.setExit("east", fruits);
        vegetables.setExit("north", cannedfood);
        fruits.setExit("west", vegetables);
        cannedfood.setExit("south", vegetables);
        cannedfood.setExit("north", bakery);
        cannedfood.setExit("west", beverages);
        bakery.setExit("south", cannedfood);
        bakery.setExit("north", cerealTeaCoffee);
        cerealTeaCoffee.setExit("south", bakery);
        cerealTeaCoffee.setExit("north", dairyEggs);
        cerealTeaCoffee.setExit("north-east", meat);
        meat.setExit("south-west", cerealTeaCoffee);
        meat.setExit("west", dairyEggs);
        dairyEggs.setExit("down", staffArea);
        dairyEggs.setExit("east", meat);
        dairyEggs.setExit("south-west", snacks);
        staffArea.setExit("up", dairyEggs);
        snacks.setExit("north-east", dairyEggs);
        snacks.setExit("east", beverages);
        beverages.setExit("west", snacks);
        beverages.setExit("east", cannedfood);
        beverages.setExit("south", checkout);
        checkout.setExit("north", beverages);
        checkout.setExit("south-east", parkingLot);
        checkout.setExit("up", rooftop);
        rooftop.setExit("down", checkout);
        parkingLot.setExit("north-west", checkout);
        parkingLot.setExit("north", vegetables);
        
        Item potato,melon,can,bread,teabag,egg,bottle,candy,chocolate,money,mug,shoppingcart;
        
        potato= new Item("potato","a smol potato", 3);
        melon= new Item("melon","a huge melon", 9);
        can= new Item("can","an expired can of peeled and sugared mandarins", 4);
        bread= new Item("bread","a bread loaf that's totally edible", 5);
        teabag= new Item("teabag","a peppermint flavored teabag", 1);
        egg= new Item("egg","a very normal non cracked egg", 2);
        bottle= new Item("bottle","a cheap  one liter water bottle that's half full or half empty" + "\n" + "dependig on your philosophy of life",6);
        candy= new Item("candy","a piece of candy", 1);
        chocolate= new Item("chocolatebar","a squished chocolatebar", 2);
        money= new Item("money","a 10�-bill a.k.a. ca$h", 1);
        mug= new Item("mug","an empty rainbow-colored coffemug", 4);
        shoppingcart= new Item("shoppingcart","a random shoppingcart", 10);
        
        //initialise items in rooms
        vegetables.addItem(potato);
        fruits.addItem(melon);
        cannedfood.addItem(can);
        bakery.addItem(bread);
        cerealTeaCoffee.addItem(teabag);
        dairyEggs.addItem(egg);
        beverages.addItem(bottle);
        snacks.addItem(candy);
        snacks.addItem(chocolate);
        checkout.addItem(money);
        staffArea.addItem(mug);
        parkingLot.addItem(shoppingcart);
        
        startRoom = vegetables;  // start game 
        
    }
    
}
