import java.util.HashMap;
import java.util.Set;

public class Item
{
    private String itemDescription;
    private String name;
    private int weight;

    /**
     * Konstruktor f�r Objekte der Klasse Item
     */
    public Item(String name,String itemDescription, int weight)
    {
        this.name = name;
        this.itemDescription = itemDescription;
        this.weight = weight;
    }

    /**
     * @return The description of the item.
     */
    public String getItemDescription(){
       return itemDescription;
    }
    
    public int getweight()
    {
        return weight;
    }
    
    public String getItemName()
    {
        return name;
    }
}
