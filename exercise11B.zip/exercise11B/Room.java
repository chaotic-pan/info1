/**
 * Class Room - a room in an adventure game.
 *
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 *
 * A "Room" represents one location in the scenery of the game.  It is 
 * connected to other rooms via exits.  The exits are labelled north, 
 * east, south, west.  For each direction, the room stores a reference
 * to the neighboring room, or null if there is no exit in that direction.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class Room 
{
    private String description;
    private HashSet<Item> items;
    private HashMap<String, Room> exits;    
    private HashSet<Item> inventory;
    

    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open court yard".
     * @param description The room's description.
     */
    public Room(String description) 
    {
        this.description = description;
        exits = new HashMap<>();
        items = new HashSet<>();
        inventory = new HashSet<>();
    }

    /**
     * Define the exit and neighbor of this room.
     * @param direction.
     * @param neighbor.
     */
    public void setExit(String direction, Room neighbor) 
    {
        exits.put(direction, neighbor);
    }
    
    public void addItem(Item item)
    {
        items.add(item);
    }
    
    public void takeItem(Item it)
    {
        items.remove(it);
        inventory.add(it);
    }
    
    public Room getExit(String direction){
       return exits.get(direction);
    }
    
    public Item getItem(){
       Item thing=null;
       for(Item it : items){
            thing=it;
        }
       return thing;
    }
    
    public String getExitString(){
        String returnString = "Exits:";
        Set<String> keys = exits.keySet();
        for(String exit : keys){
            returnString += " " + exit;
        }
        return returnString;
    }
    
    public String getItemString()
    {
        String result="";
        for (Item it : items){
            result+="There is " + it.getItemDescription()+ "." + "\n";
            result+="This item weighs "+ it.getweight() + " on your personal weightscale" +"\n";
            result+= "(You are a child, so you don't know any common units...duh)"+ "\n";
        }
        return result;
    }
    
    public String getItemNameString()
    {
        String result="";
        for (Item it : items){
            result+=it.getItemName();
        }
        return result;
    }
    
    public HashSet getItemNameHashSet(){
       HashSet<Item> A = new HashSet<>();
       for (Item it : items){
           Item thing= it;
           A.add(thing);
        }
       return A;
    }
    
    /**
     * @return The description of the room.
     */
    public String getDescription()
    {
        return description;
    }
}