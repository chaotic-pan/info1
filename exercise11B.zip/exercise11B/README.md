exercise10
==========

A bad zuul with Unit Tests, used for [Exercise 10 in Info1](http://bkleinen.github.io/ws2015/info1/labs/exercise-10.html).

There is also a version using an inheritance hierarchy for the Commands in the 
branch [commandhierarchy](https://github.com/htw-imi-info1/exercise10/tree/commandhierarchy) -
you can use that if you like. It doesn't have any other refactorings.


Original Readme.txt
================================================================================
Project: zuul-bad
Authors: Michael Kolling and David J. Barnes

This project is part of the material for the book

   Objects First with Java - A Practical Introduction using BlueJ
   Fourth edition
   David J. Barnes and Michael Kolling
   Pearson Education, 2008

This project is a simple framework for an adventure game. In this version,
it has a few rooms and the ability for a player to walk between these rooms.
That's all.

To start this application, create an instance of class "Game" and call its
"play" method.

This version of the game contains some very bad class design. It should NOT
be used as a basis for extending the project without fixing these design
problems. It serves as an example to discuss good and bad design (chapter 7
of the book).

Chapter 7 of the book contains a detailed description of the problems in this
project, and how to fix them.

The project 'zuul-better' contains a version of this project with better
designed class structure. It includes the fixes discussed in the book.
